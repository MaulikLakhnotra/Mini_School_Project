<?php
    class Stud extends CI_Controller
    {
        public function home()
        {
            redirect ('user/create');
        }
    }
?>